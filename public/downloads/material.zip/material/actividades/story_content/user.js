function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6fxg5S2kJAw":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

